package com.college.yi.bookmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookmanagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
